﻿
namespace Data.Enum
{
    class CustomClaimTypes
    {
    }
}
