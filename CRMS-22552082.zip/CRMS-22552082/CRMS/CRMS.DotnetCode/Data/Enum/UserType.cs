﻿
namespace Data.Enum
{
   public enum UserType :byte
    {
        FacilityManager=1,
        Employee = 2
    }
}
