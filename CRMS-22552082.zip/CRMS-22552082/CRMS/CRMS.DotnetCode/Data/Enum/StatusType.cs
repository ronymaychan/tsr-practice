﻿
namespace Data.Enum
{
   public enum StatusType:byte
    {
       Disabled=0,
       Enabled=1
    }
}
