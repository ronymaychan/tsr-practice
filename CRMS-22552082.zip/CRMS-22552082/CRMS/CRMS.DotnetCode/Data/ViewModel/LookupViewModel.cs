﻿
namespace Data.ViewModel
{
    public class LookupViewModel
    {
        public long Key { get; set; }
        public string Value { get; set; }
    }
}
