﻿
namespace Data.Entity
{
   public class RoomType :BaseEntity
    {
        public string RoomTypeName { get; set; }
    }
}
