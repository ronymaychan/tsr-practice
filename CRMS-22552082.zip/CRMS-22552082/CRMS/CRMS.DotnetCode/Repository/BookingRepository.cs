﻿using Data;
using Data.Entity;
using Repository.Interfaces;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Repository
{
    public class BookingRepository : GenericRepository<Booking>, IBookingRepository
    {
        private IRoomRepository _roomRepository;
        public BookingRepository(CRMSDbContext dbContext, IRoomRepository roomRepository) : base(dbContext)
        {
            _roomRepository = roomRepository;
        }

        public async Task CancelBooking(Booking b)
        {
            var booking = await _dbSet.FindAsync(b.Id);
            booking.IsCancelled = true;
            Update(booking);
        }

        public async Task SaveBooking(Booking booking)
        {
            if (await IsRoomAvailable(booking))
            {
                await InsertAsync(booking);
            }
            else
            {
                throw new Exception("Selected room is not available!!!!");
            }
        }

        private async Task<bool> IsRoomAvailable(Booking b)
        {
            //getting  availability
            var bookings = await GetAsync(x => x.RoomId == b.RoomId
                                            && x.IsCancelled == false
                                            && ( (b.StartDateTs > x.StartDateTs && b.StartDateTs < x.EndDateTs) || (b.EndDateTs > x.StartDateTs && b.EndDateTs < x.EndDateTs))
                                    , null, "ConfreneceRoom");

            var isAvailable = bookings.Count() == 0;

            return await Task.FromResult(isAvailable);
        }
    }
}
