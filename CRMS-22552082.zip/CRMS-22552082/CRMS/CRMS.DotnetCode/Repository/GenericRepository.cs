﻿using Data;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Repository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        protected CRMSDbContext _dbContext;
        protected readonly DbSet<T> _dbSet;
        public GenericRepository(CRMSDbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = dbContext.Set<T>();
        }

        public async Task<IEnumerable<T>> GetAsync(Expression<Func<T, bool>> filter = null,
            Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, string includeProperties = "")
        {
            IQueryable<T> query = _dbSet;

            if (filter != null)
                query = query.Where(filter);

            if (!string.IsNullOrEmpty(includeProperties))
            {
                var includeList = includeProperties.Split('|');
                foreach (var include in includeList)
                    query = query.Include(include);
            }

            if (orderBy != null)
                query = orderBy(query);

            return await query.ToListAsync();
        }

        public async Task<T> GetByIDAsync(long id) 
        {
            var item = await _dbSet.FindAsync(id);
            return item;
        }

        public async Task InsertAsync(T entity) 
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _dbContext.Entry<T>(entity).State = EntityState.Added;
            _dbSet.Add(entity);
        }

        public async Task DeleteAsync(long id) 
        {
            var item = await _dbSet.FindAsync(id);

            if (!_dbSet.Local.Any(e => e == item))
                _dbSet.Attach(item);
            _dbContext.Entry(item).State = EntityState.Deleted;
        }

        public void Delete(T entityToDelete)
        {
            if (!_dbSet.Local.Any(e => e == entityToDelete))
                _dbSet.Attach(entityToDelete);
            _dbContext.Entry(entityToDelete).State = EntityState.Deleted;
        }

        public void Update(T entityToUpdate)
        {
            if (!_dbSet.Local.Any(e => e == entityToUpdate))
                _dbSet.Attach(entityToUpdate);

            _dbContext.Entry<T>(entityToUpdate).State = EntityState.Modified;
        }

        public void Save(T entity)
        {
            if (!_dbSet.Local.Any(e => e == entity))
                _dbSet.Attach(entity);

            _dbContext.Entry<T>(entity).State = EntityState.Modified;
        }
    }
}
