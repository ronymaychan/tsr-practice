﻿using Data;
using Data.Entity;
using Repository.Interfaces;

namespace Repository
{
   public class RoomTypeRepository: GenericRepository<RoomType>, IRoomTypeRepository
    {
        private readonly CRMSDbContext _dBContext;

        public RoomTypeRepository(CRMSDbContext dbContext) : base(dbContext)
        {
            _dBContext = dbContext;
        }
    }
}
