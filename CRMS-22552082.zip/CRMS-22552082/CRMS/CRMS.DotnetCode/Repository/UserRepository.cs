﻿using Data;
using Data.Entity;
using Repository.Interfaces;

namespace Repository
{
    public class UserRepository : GenericRepository<User>, IUserRepository
    {
        private readonly CRMSDbContext _dBContext;

        public UserRepository(CRMSDbContext dbContext) : base(dbContext)
        {
            _dBContext = dbContext;
        }
    }
}
