﻿using Data;
using Data.Entity;
using Data.ViewModel;
using Microsoft.AspNet.Identity;
using Repository.Interfaces;
using System.Threading.Tasks;

namespace Repository
{
    public class AuthRepository : IAuthRepository
    {
        private CRMSDbContext dbContext;
        private UserManager<User> _userManager;
        public AuthRepository(CRMSDbContext context, UserManager<User> userManager)
        {
            dbContext = context;
            _userManager = userManager;
        }

        public async Task<User> FindUserAsync(string userName, string password)
        {

            var user = await _userManager.FindByNameAsync(userName);
            if (user == null)
                return null;

            var result = await _userManager.FindAsync(userName, password);
            return result;
        }

        public async Task<IdentityResult> RegisterAsync(RegisterViewModel model)
        {
            User user = new User()
            {
                EmpID = model.EmpID,
                Firstname = model.Firstname,
                Lastname = model.Lastname,
                UserType = model.UserType,
                Email = model.Email,
                PhoneNumber = model.PhoneNumber,
                EmpAddress = model.EmpAddress,
                UserName = model.Email
            };

            var result = await _userManager.CreateAsync(user, model.Password.Trim());

            return result;
        }
    }
}
