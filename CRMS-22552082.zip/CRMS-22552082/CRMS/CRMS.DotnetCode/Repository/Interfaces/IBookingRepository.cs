﻿using Data.Entity;
using System.Threading.Tasks;

namespace Repository.Interfaces
{
   public interface IBookingRepository : IGenericRepository<Booking>
    {
       Task SaveBooking(Booking booking);

       Task CancelBooking(Booking booking);
    }
}
