﻿using Data.Entity;
using Data.ViewModel;
using Microsoft.AspNet.Identity;
using System.Threading.Tasks;

namespace Repository.Interfaces
{
    public interface IAuthRepository
    {
        Task<IdentityResult> RegisterAsync(RegisterViewModel model);

        Task<User> FindUserAsync(string userName, string password);
    }
}
