﻿using System.Threading.Tasks;

namespace Repository.Interfaces
{
    public interface IUow
    {
        IUserRepository UserRepository { get; }
        IRoomRepository RoomRepository { get; }
        IBookingRepository BookingRepository { get; }
        IRoomTypeRepository RoomTypeRepository { get; }
        IAuthRepository AuthRepository { get; }

        void Save();

        Task SaveAsync();
    }
}
