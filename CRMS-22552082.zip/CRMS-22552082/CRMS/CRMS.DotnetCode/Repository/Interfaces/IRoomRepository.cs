﻿using Data.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repository.Interfaces
{
    public interface IRoomRepository : IGenericRepository<ConfreneceRoom>
    {
        Task<IEnumerable<ConfreneceRoom>> GetActiveRooms();
    }
}
