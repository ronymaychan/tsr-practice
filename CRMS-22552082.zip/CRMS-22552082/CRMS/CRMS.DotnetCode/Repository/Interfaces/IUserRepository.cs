﻿using Data.Entity;

namespace Repository.Interfaces
{
    public interface IUserRepository: IGenericRepository<User>
    {
    }
}
