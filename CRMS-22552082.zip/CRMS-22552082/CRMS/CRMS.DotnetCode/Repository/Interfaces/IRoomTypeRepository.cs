﻿using Data.Entity;

namespace Repository.Interfaces
{
    public interface IRoomTypeRepository : IGenericRepository<RoomType>
    {
    }
}
