﻿using Data;
using Data.Entity;
using Repository.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repository
{
    public class RoomRepository : GenericRepository<ConfreneceRoom>, IRoomRepository
    {
        private readonly CRMSDbContext _dBContext;

        public RoomRepository(CRMSDbContext dbContext) : base(dbContext)
        {
            _dBContext = dbContext;
        }

        public Task<IEnumerable<ConfreneceRoom>> GetActiveRooms()
        {
            return GetAsync(x => x.IsActive == true);
        }
    }
}
