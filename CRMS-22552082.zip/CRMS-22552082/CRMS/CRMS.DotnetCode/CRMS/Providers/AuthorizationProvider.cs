﻿using Microsoft.Owin.Security.OAuth;
using System.Threading.Tasks;

namespace CRMS.Providers
{
    public class AuthorizationProvider : OAuthAuthorizationServerProvider
    {
        public AuthorizationProvider()
        {
        }

        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
            return Task.FromResult<object>(null);
        }
       
    }
}