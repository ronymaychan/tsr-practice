﻿using AutoMapper;
using Data.Entity;
using Data.ViewModel;

namespace CRMS.Providers
{
    public class AutoMapperProvider
    {
        public static IMapper CreateMapper()
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<Booking, BookingViewModel>()
                .ForMember(d => d.RoomName, opt => opt.MapFrom(s => s.ConfreneceRoom.Name))
                .ForMember(d => d.RoomLocation, opt => opt.MapFrom(s => s.ConfreneceRoom.Location))
                .ForMember(d => d.BookedBy, opt => opt.MapFrom(s => s.Employee.Firstname + " " + s.Employee.Lastname));
            });

            return config.CreateMapper();
        }
    }
}