﻿using Autofac;
using Autofac.Integration.WebApi;
using CRMS.Providers;
using Data;
using log4net;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using Owin;
using Repository;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.Http;

[assembly: OwinStartup(typeof(CRMS.Startup))]
namespace CRMS
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();
            WebApiConfig.Register(config);

            app.UseCors(CorsOptions.AllowAll);


            var builder = new ContainerBuilder();


            builder.RegisterType<Uow>().As<IUow>();

            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());
            builder.Register(c => LogManager.GetLogger("CRMSLogger")).As<ILog>(); // Log4Net Dependency Injection


            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);

            ConfigureOAuth(app);


            app.UseCors(CorsOptions.AllowAll);
            app.UseWebApi(config);


        }

        public void ConfigureOAuth(IAppBuilder app)
        {

            app.CreatePerOwinContext<CRMSDbContext>(() => new CRMSDbContext());
            app.CreatePerOwinContext<UserManager<IdentityUser>>(CreateManager);
            OAuthAuthorizationServerOptions OAuthServerOptions = new OAuthAuthorizationServerOptions()
            {
                AllowInsecureHttp = true,
                TokenEndpointPath = new PathString("/api/oauth/token"),
                AccessTokenExpireTimeSpan = TimeSpan.FromDays(30),
                Provider = new CustomOAuthProvider(),
                AccessTokenFormat = new CustomJwtFormat("http://jwtauthzsrv.azurewebsites.net")
            };

            // OAuth 2.0 Bearer Access Token Generation
            app.UseOAuthAuthorizationServer(OAuthServerOptions);

        }

        private static UserManager<IdentityUser> CreateManager(IdentityFactoryOptions<UserManager<IdentityUser>> options, IOwinContext context)
        {
            var userStore = new UserStore<IdentityUser>(context.Get<CRMSDbContext>());
            var owinManager = new UserManager<IdentityUser>(userStore);
            return owinManager;
        }
        public static AuthenticationProperties CreateProperties(IDictionary<string, string> customProperties)
        {
            return new AuthenticationProperties(customProperties);
        }
    }
}