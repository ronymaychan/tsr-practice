﻿using Data.Entity;
using Data.ViewModel;
using log4net;
using Repository.Interfaces;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;

namespace CRMS.Controllers
{
    [RoutePrefix("Room")]
    public class RoomController : BaseApiController
    {
        private IUow _uow;
        private ILog _log;

        public RoomController(IUow uow, ILog log)
        {
            _uow = uow;
            _log = log;
        }

        public async Task<IHttpActionResult> GetRooms()
        {
            return Ok(await this._uow.RoomRepository.GetAsync());
        }

        public async Task<IHttpActionResult> GetActiveRooms()
        {

            return Ok(await this._uow.RoomRepository.GetActiveRooms());
        }

        public async Task<IHttpActionResult> GetRoomsLookup()
        {
            var activesRooms = await this._uow.RoomRepository.GetActiveRooms();

            var items = activesRooms.Select(x => new LookupViewModel() { Key = x.Id, Value = x.Name });

            return Ok(items);
        }

        [HttpPost]
        public async Task<IHttpActionResult> Save(ConfreneceRoom room)
        {
            if (room.Id == 0)
            {
                PopulateMetaData(room);
                await _uow.RoomRepository.InsertAsync(room);
                await _uow.SaveAsync();
            }
            else
            {
                var sourceRoom = await _uow.RoomRepository.GetByIDAsync(room.Id);
                PopulateMetaData(sourceRoom);
                sourceRoom.PopulateForUpdate(room);
                _uow.RoomRepository.Update(sourceRoom);
                await _uow.SaveAsync();
            }

            return Ok(await _uow.RoomRepository.GetByIDAsync(room.Id));
        }


        [HttpDelete]
        public async Task<IHttpActionResult> Delete(long id)
        {
            await _uow.RoomRepository.DeleteAsync(id);
            await _uow.SaveAsync();
            return Ok();
        }
    }
}
