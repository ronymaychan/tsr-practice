﻿
namespace CRMS.Controllers
{
    public class ReportController : BaseApiController
    {
    }
}
