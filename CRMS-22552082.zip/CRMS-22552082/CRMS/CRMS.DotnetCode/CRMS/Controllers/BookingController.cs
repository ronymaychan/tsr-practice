﻿using AutoMapper;
using CRMS.Providers;
using Data.Entity;
using Data.ViewModel;
using log4net;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace CRMS.Controllers
{
    public class BookingController : BaseApiController
    {
        private readonly IUow _uow;
        private readonly ILog _log;
        private readonly IMapper _mapper;

        public BookingController(IUow uow, ILog log)
        {
            _uow = uow;
            _log = log;
            _mapper = AutoMapperProvider.CreateMapper();
        }

        public async Task<IHttpActionResult> GetBookings()
        {
            var oBookingList = await _uow.BookingRepository.GetAsync(null, null, "ConfreneceRoom|Employee");
            var models = _mapper.Map<List<BookingViewModel>>(oBookingList);
            return Ok(models);
        }

        public async Task<IHttpActionResult> GetBookingsByUser(string userId)
        {

            var oBookingList = await _uow.BookingRepository.GetAsync(x => x.UserId == userId);
            var models = _mapper.Map<List<BookingViewModel>>(oBookingList);
            return Ok(models);
        }

        public async Task<IHttpActionResult> GetCurrentMonthBookings(string userId = "")
        {
            var currentYear = DateTime.Now.Year;
            var currentMonth = DateTime.Now.Month;

            var oBookingList = await _uow.BookingRepository.GetAsync(x => x.UserId == userId &&
                ((x.StartDateTs.Year == currentYear && x.StartDateTs.Month == currentMonth) || (x.EndDateTs.Year == currentYear && x.EndDateTs.Month == currentMonth)));

            var models = _mapper.Map<List<BookingViewModel>>(oBookingList);
            return Ok(models);
        }

        [HttpPost]
        public async Task<IHttpActionResult> Save(Booking booking)
        {
            PopulateMetaData(booking);
            await _uow.BookingRepository.SaveBooking(booking);
            await _uow.SaveAsync();
            return Ok();
        }

        [HttpPut]
        public async Task<IHttpActionResult> CancelBooking(Booking oBooking) 
        {
            await _uow.BookingRepository.CancelBooking(oBooking);
            await _uow.SaveAsync();
            return Ok();
        }

        [HttpDelete]
        public async Task<IHttpActionResult> DeleteAsync(long id) 
        {
            await _uow.BookingRepository.DeleteAsync(id);
            await _uow.SaveAsync();
            return Ok();
        }
    }
}