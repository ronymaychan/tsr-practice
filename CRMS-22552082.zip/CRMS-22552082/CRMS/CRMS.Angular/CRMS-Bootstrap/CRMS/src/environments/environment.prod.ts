export const environment = {
  production: true,
  version: '(prod)',
  serverUrl: 'http://localhost:80/crms_51766/api/'
};
