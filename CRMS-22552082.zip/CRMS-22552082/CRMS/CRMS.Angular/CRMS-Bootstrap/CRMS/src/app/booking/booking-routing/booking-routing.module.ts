import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookingComponent } from '../booking.component';
import { AuthenticationGuardService } from '../../core/authentication/authentication-guard.service' 

const routes: Routes = [
  { path: '', canActivate: [AuthenticationGuardService], component: BookingComponent, data: { title: 'Booking' } }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class BookingRoutingModule { }

