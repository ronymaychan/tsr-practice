import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookingformComponent } from './bookingform.component';
import { BookingFormRoutingModule } from './booking-form-routing/booking-form-routing.module';


@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule,
    BookingFormRoutingModule
  ]
})
export class BookingformModule { }
