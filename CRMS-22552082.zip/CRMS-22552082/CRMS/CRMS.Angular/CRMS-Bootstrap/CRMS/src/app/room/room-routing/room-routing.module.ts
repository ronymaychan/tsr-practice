import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RoomComponent } from '../room.component';
import { AuthenticationGuardService } from '../../core/authentication/authentication-guard.service';

const routes: Routes = [
  { path: '', canActivate: [AuthenticationGuardService], component: RoomComponent, data: { title: 'Manage Rooms' } }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class RoomRoutingModule { }
