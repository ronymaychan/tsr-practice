import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookingRoutingModule } from './booking/booking-routing/booking-routing.module';
import { BookingFormRoutingModule } from './booking/bookingform/booking-form-routing/booking-form-routing.module';
import { RegisterRoutingModule } from './register/register-routing/register-routing.module';
import { RoomFormRoutingModule } from './room/roomform/room-form-routing/room-form-routing.module';

const routes: Routes = [
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then(m => m.LoginModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: 'booking',
    loadChildren: () => import('./booking/booking.module').then(m => m.BookingModule)
  },
  {
    path: 'room',
    loadChildren: () => import('./room/room.module').then(m => m.RoomModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then(m => m.RegisterModule)
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  { path: '**', redirectTo: 'login', pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes), 
    RoomFormRoutingModule, 
    RegisterRoutingModule,
    BookingRoutingModule,
    BookingFormRoutingModule],
  exports: [
    RouterModule
  ],
  providers: []
})
export class AppRoutingModule { }
