import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoomFormRoutingModule } from './room-form-routing/room-form-routing.module'

@NgModule({
  declarations: [
    
  ],
  imports: [
    CommonModule,
    RoomFormRoutingModule
  ]
})
export class RoomformModule { }
