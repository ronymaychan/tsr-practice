import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import * as moment from 'moment';
import { AuthcredentialstoreService } from '../../core/authentication/authcredentialstore.service';

import { environment } from '../../..//environments/environment';
import { stringify } from '@angular/compiler/src/util';

@Component({
  selector: 'app-bookingform',
  templateUrl: './bookingform.component.html',
  styleUrls: ['./bookingform.component.scss']
})
export class BookingformComponent implements OnInit {

  roomList: any;
  bookingForm: FormGroup|any;
  isAddForm = true;
  mindate = new Date();
  errors = [];
  filteredOptions: any;
  roomControl: FormControl = new FormControl();
  filteredRoomList: any=[];


  constructor(private formBuilder: FormBuilder,
    private http: HttpClient,
    private toast: ToastrService,
    private router: Router, private route: ActivatedRoute, private authstore: AuthcredentialstoreService) { }

  ngOnInit() {
    this.createForm();
    this.initBindControls();
    this.roomControl.valueChanges.subscribe(newValue => {
      this.filteredRoomList = this.filter(newValue);
    });
  }

  filter(val: string): any[] {
    return this.roomList.filter((room:any) =>
      room.value.toLowerCase().indexOf(val.toString().toLowerCase()) > -1);
  }

  displayFn(room?: any): string | undefined {
    return room ? room.value : undefined;
  }

  formatDatetime(datestr:any, timestr:any) {
    const dateformated = moment(datestr).format('DD/MM/YYYY');
    // var timeformated = moment(timestr).format('HH:mm');
    const datetime = moment(dateformated + ' ' + timestr, 'DD/MM/YYYY HH:mm');
    return datetime.format('YYYY/MM/DD HH:mm');
  }


  save() {
    console.log(this.bookingForm.value);
    console.log(this.roomControl);
    console.log(this.roomControl.value);
    const formvalue = this.bookingForm.value;
    const bookingData = {
      startDateTs: this.formatDatetime(formvalue.startDate, formvalue.startTime),
      endDateTs: this.formatDatetime(formvalue.endDate, formvalue.endTime),
      //roomId: this.roomControl.value.key,
      roomId: formvalue.roomId,
      userId: this.authstore.credentials!.userid
    };

    let headers =  new HttpHeaders({
      'Content-Type': 'application/json'
    });

    console.log(bookingData);
    let body = JSON.stringify(bookingData);
    console.log(body);
    this.http.post(environment.serverUrl + 'booking/Save', body, { headers }).subscribe((res:any) => {
      this.toast.success('Room booked Successfully!!!');
      this.router.navigate(['/booking'], { replaceUrl: true });
    }, (err:any) => {
      console.log("error", err);
      console.log("model state", err.error.modelState);
      const error = err.error;
      this.handleException(error);
    });
  }

  handleException(error:any) {
    if (error.exceptionMessage) {
      // Unhandled Exception
      this.toast.error(error.exceptionMessage);
    } else if (error.modelState) {
  
      for (const propname of Object.keys(error.modelState)) {
        this.toast.error(error.modelState[propname] );
        this.errors.push(error.modelState[propname] as never);
      }
    } else {
      console.log(error);
    }
  }

  onFormMouseLeave(event:any) {
    console.log(event);
    this.errors = [];
  }
  initBindControls() {
    this.http.get(environment.serverUrl + 'room/GetRoomsLookup')
      .subscribe((data:any) => {
        this.roomList = data;
        console.log(this.roomList);
        this.filteredRoomList = this.roomList;

      });
  }

  private createForm() {
    this.bookingForm = this.formBuilder.group({
      id: 0,
      roomId: [null, [Validators.required]],
      startDate: [null, [Validators.required]],
      startTime: [null, [Validators.required]],
      endDate: [null, [Validators.required]],
      endTime: [null, [Validators.required]],
      creationTs: Date,
      createdBy: '',
      statusType: Number
    });
  }

  dateLessThan(from: string, to: string) {
    return (group: FormGroup): { [key: string]: any } => {
      const f = group.controls[from];
      const t = group.controls[to];
      if (f.value > t.value) {
        return {
          dates: 'Date from should be less than Date to'
        };
      }
      return {};
    };
  }
}
