import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookingformComponent } from '../bookingform.component';
import { AuthenticationGuardService } from '../../../core/authentication/authentication-guard.service';

const routes: Routes = [
  { path: 'booking/form',canActivate: [AuthenticationGuardService], component: BookingformComponent, data: { title: 'Add/Edit Booking' } }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class BookingFormRoutingModule { }
