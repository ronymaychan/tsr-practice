import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RoomformComponent } from '../roomform.component';
import { AuthenticationGuardService } from '../../../core/authentication/authentication-guard.service';

const routes: Routes = [
  { path: 'room/form',canActivate: [AuthenticationGuardService], component: RoomformComponent, data: { title: 'Add/Edit Room' } }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class RoomFormRoutingModule { }
