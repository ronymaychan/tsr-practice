import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

import { AuthenticationService } from './authentication.service';
import { AuthcredentialstoreService } from './authcredentialstore.service';

@Injectable({'providedIn':'root'})
export class AuthenticationGuardService implements CanActivate {

  constructor(private router: Router,
    private authStore: AuthcredentialstoreService) { }

    canActivate(): boolean {


      console.log('bfore Not authenticated, redirecting...');

      if (this.authStore.isAuthenticated()) {
        return true;
      }
  
      console.log('Not authenticated, redirecting...');
      this.router.navigate(['/login'], { replaceUrl: true });
      return false;
    }  
}
