import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatAutocompleteModule } from '@angular/material/autocomplete'; 
import { MatTableModule} from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCardModule } from '@angular/material/card';
import { MatListModule} from '@angular/material/list';
import { MatSelectFilterModule } from 'mat-select-filter';


@NgModule({
  imports:
   [MatTableModule,
    MatPaginatorModule,
    MatSlideToggleModule,
    MatDatepickerModule,
    MatAutocompleteModule, 
    MatCardModule, 
    MatListModule,
    MatSelectFilterModule 
   ],
  exports:
  [MatTableModule,
   MatPaginatorModule,
   MatSlideToggleModule,
   MatDatepickerModule,
   MatAutocompleteModule,
   MatCardModule,
   MatListModule],
  declarations: []
})
export class MatmoduleModule { }
