
use crms_xxxxx;/*where xxxx is your employee id . Please replace before executing.*/

CREATE LOGIN localhost WITH PASSWORD = 'localhost',
CHECK_POLICY = OFF,
    CHECK_EXPIRATION = OFF;
GO
Use crms_xxxxx;
GO

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'localhost')
BEGIN
    CREATE USER [localhost] FOR LOGIN [localhost]
    EXEC sp_addrolemember N'db_owner', N'localhost'
END;
GO