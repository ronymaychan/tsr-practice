﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssetDispatchMgr.Data.Model
{
    public class AssetInventory
    {
        public int Id { get; set; }
        public string SerialNumber { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsAsigned { get; set; }
    }
}
