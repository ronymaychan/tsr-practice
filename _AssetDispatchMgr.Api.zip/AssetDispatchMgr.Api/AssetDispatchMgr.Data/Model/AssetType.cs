﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssetDispatchMgr.Data.Model
{
    public class AssetType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
