﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace AssetDispatchMgr.Data.Model
{
    public class AppUser : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        //privilages
        public bool IsAdmin { get; set; }
        public bool IsConsultant { get; set; }
        public bool IsManager { get; set; }
    }
}
