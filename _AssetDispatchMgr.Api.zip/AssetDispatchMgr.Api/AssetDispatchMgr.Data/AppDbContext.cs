﻿using AssetDispatchMgr.Data.Model;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace AssetDispatchMgr.Data
{
    public class AppDbContext : IdentityDbContext<AppUser, AppRole, string>
    {
        public DbSet<AssetType> AssetTypes { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {

            builder.Entity<AssetType>(x =>
            {
                x.HasKey(x => x.Id);
                x.Property(x => x.Id).ValueGeneratedOnAdd();
                x.Property(x => x.Name).HasMaxLength(50).IsRequired();
                x.ToTable("PropertyType");
            });

            // asset type default data
            builder.Entity<AssetType>().HasData(new AssetType { Id = 1, Name = "Desktop" });
            builder.Entity<AssetType>().HasData(new AssetType { Id = 2, Name = "Laptop" });
            builder.Entity<AssetType>().HasData(new AssetType { Id = 3, Name = "Mouse" });
            builder.Entity<AssetType>().HasData(new AssetType { Id = 4, Name = "Headset" });
            builder.Entity<AssetType>().HasData(new AssetType { Id = 5, Name = "Monitor" });

            // user app user default data
            builder.Entity<AppUser>().HasData(new AppUser()
            {
                Id = Guid.NewGuid().ToString(),
                Email = "admin1@hexaware.com",
                UserName = "admin1@hexaware.com",
                NormalizedEmail = "ADMIN1@HEXAWARE.COM",
                NormalizedUserName = "ADMIN1@HEXAWARE.COM",
                EmailConfirmed = false,
                PasswordHash = "AQAAAAEAACcQAAAAEEyOxPSQeYmvCP/SJX66w5plDUCJbQ5+QcwlcsJkEv7QdlomnmxMJjIrVqnf3gQY7g==",
                SecurityStamp = "VL47RAX6JXPCDKCUH3JSNBQY3T32MOMC",
                ConcurrencyStamp = "ca83c571-ea33-492f-9132-c94dcef02477",
                PhoneNumberConfirmed = false,
                TwoFactorEnabled = false,
                LockoutEnabled = true,
                AccessFailedCount = 0,
                FirstName = "",
                LastName = "",
                IsAdmin = true,
                IsConsultant = true, 
                IsManager = true
            });
            builder.Entity<AppUser>().HasData(new AppUser()
            {
                Id = Guid.NewGuid().ToString(),
                Email = "manager1@hexaware.com",
                UserName = "manager1@hexaware.com",
                NormalizedEmail = "MANAGER1@HEXAWARE.COM",
                NormalizedUserName = "MANAGER1@HEXAWARE.COM",
                EmailConfirmed = false,
                PasswordHash = "AQAAAAEAACcQAAAAEEyOxPSQeYmvCP/SJX66w5plDUCJbQ5+QcwlcsJkEv7QdlomnmxMJjIrVqnf3gQY7g==",
                SecurityStamp = "VL47RAX6JXPCDKCUH3JSNBQY3T32MOMC",
                ConcurrencyStamp = "ca83c571-ea33-492f-9132-c94dcef02477",
                PhoneNumberConfirmed = false,
                TwoFactorEnabled = false,
                LockoutEnabled = true,
                AccessFailedCount = 0,
                FirstName = "",
                LastName = "",
                IsAdmin = false,
                IsConsultant = false,
                IsManager = true
            });
            builder.Entity<AppUser>().HasData(new AppUser()
            {
                Id = Guid.NewGuid().ToString(),
                Email = "manager2@hexaware.com",
                UserName = "manager2@hexaware.com",
                NormalizedEmail = "MANAGER2@HEXAWARE.COM",
                NormalizedUserName = "MANAGER2@HEXAWARE.COM",
                EmailConfirmed = false,
                PasswordHash = "AQAAAAEAACcQAAAAEEyOxPSQeYmvCP/SJX66w5plDUCJbQ5+QcwlcsJkEv7QdlomnmxMJjIrVqnf3gQY7g==",
                SecurityStamp = "VL47RAX6JXPCDKCUH3JSNBQY3T32MOMC",
                ConcurrencyStamp = "ca83c571-ea33-492f-9132-c94dcef02477",
                PhoneNumberConfirmed = false,
                TwoFactorEnabled = false,
                LockoutEnabled = true,
                AccessFailedCount = 0,
                FirstName = "",
                LastName = "",
                IsAdmin = false,
                IsConsultant = false,
                IsManager = true
            });
            builder.Entity<AppUser>().HasData(new AppUser()
            {
                Id = Guid.NewGuid().ToString(),
                Email = "consultant1@hexaware.com",
                UserName = "consultant1@hexaware.com",
                NormalizedEmail = "CONSULTANT1@HEXAWARE.COM",
                NormalizedUserName = "CONSULTANT1@HEXAWARE.COM",
                EmailConfirmed = false,
                PasswordHash = "AQAAAAEAACcQAAAAEEyOxPSQeYmvCP/SJX66w5plDUCJbQ5+QcwlcsJkEv7QdlomnmxMJjIrVqnf3gQY7g==",
                SecurityStamp = "VL47RAX6JXPCDKCUH3JSNBQY3T32MOMC",
                ConcurrencyStamp = "ca83c571-ea33-492f-9132-c94dcef02477",
                PhoneNumberConfirmed = false,
                TwoFactorEnabled = false,
                LockoutEnabled = true,
                AccessFailedCount = 0,
                FirstName = "",
                LastName = "",
                IsAdmin = false,
                IsConsultant = true,
                IsManager = false
            });
            builder.Entity<AppUser>().HasData(new AppUser()
            {
                Id = Guid.NewGuid().ToString(),
                Email = "consultant2@hexaware.com",
                UserName = "consultant2@hexaware.com",
                NormalizedEmail = "CONSULTANT2@HEXAWARE.COM",
                NormalizedUserName = "CONSULTANT2@HEXAWARE.COM",
                EmailConfirmed = false,
                PasswordHash = "AQAAAAEAACcQAAAAEEyOxPSQeYmvCP/SJX66w5plDUCJbQ5+QcwlcsJkEv7QdlomnmxMJjIrVqnf3gQY7g==",
                SecurityStamp = "VL47RAX6JXPCDKCUH3JSNBQY3T32MOMC",
                ConcurrencyStamp = "ca83c571-ea33-492f-9132-c94dcef02477",
                PhoneNumberConfirmed = false,
                TwoFactorEnabled = false,
                LockoutEnabled = true,
                AccessFailedCount = 0,
                FirstName = "",
                LastName = "",
                IsAdmin = false,
                IsConsultant = true,
                IsManager = false
            });

            base.OnModelCreating(builder);
        }
    }
}
