﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AssetDispatchMgr.Data.Base
{
    public abstract class BaseRepository<TEntity> where TEntity : class
    {
        protected AppDbContext _context;
        protected readonly DbSet<TEntity> _dbSet;
        public BaseRepository(AppDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<TEntity>();
        }
        public virtual IQueryable<TEntity> GetAllQry()
        {
            return _dbSet;
        }
        public virtual TEntity FindById(params object[] keyValues)
        {
            return _dbSet.Find(keyValues);
        }
        public virtual void Insert(IEnumerable<TEntity> entities)
        {
            foreach (var entity in entities)
            {
                Insert(entity);
            }
            _context.SaveChanges();
        }
        public virtual void Insert(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _context.Entry<TEntity>(entity).State = EntityState.Added;
            _dbSet.Add(entity);
            _context.SaveChanges();
        }
        public virtual void Update(TEntity entity)
        {
            if (!_dbSet.Local.Any(e => e == entity))
                _dbSet.Attach(entity);

            _context.Entry<TEntity>(entity).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public virtual void Delete(TEntity entity)
        {
            if (!_dbSet.Local.Any(e => e == entity))
                _dbSet.Attach(entity);
            _context.Entry(entity).State = EntityState.Deleted;
            _context.SaveChanges();
        }
        public virtual void Delete(IEnumerable<TEntity> entities)
        {
            foreach (var entity in entities)
            {
                Delete(entity);
            }
            _context.SaveChanges();
        }
    }
}
