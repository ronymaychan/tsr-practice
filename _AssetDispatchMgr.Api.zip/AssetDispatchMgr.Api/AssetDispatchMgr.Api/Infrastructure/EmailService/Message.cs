﻿using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AssetDispatchMgr.Api.Infrastructure.EmailService
{
    public class Message
    {
        public List<MailboxAddress> ToList { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }

        public Message(IEnumerable<string> toList, string subject, string content)
        {
            ToList = new List<MailboxAddress>();

            foreach (string to in toList)
                ToList.Add(new MailboxAddress(to));

            Subject = subject;
            Content = content;
        }
    }
}
