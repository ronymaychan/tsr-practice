﻿using AssetDispatchMgr.Api.Dto;
using AssetDispatchMgr.Data.Model;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace AssetDispatchMgr.Api.Jwt
{
    public class JwtManager
    {
        private JwtSettings _jwtSettings;

        public JwtManager(JwtSettings jwtSettings)
        {
            _jwtSettings = jwtSettings;
        }

        public UserAutenticatedDto BuildAthUserAsync(AppUser appUser)
        {
            UserAutenticatedDto authUser = new UserAutenticatedDto
            {
                Id = appUser.Id,
                FirstName = appUser.FirstName,
                LastName = appUser.LastName,
                Email = appUser.Email,
                Token = BuildJwtToken(appUser),
                ExpireInSeconds = _jwtSettings.DaysToExpiration * 24 * 60 * 60,
                IsAdmin = appUser.IsAdmin,
                IsManager = appUser.IsManager,
                IsConsultant = appUser.IsConsultant
            };

            return authUser;
        }

        public string BuildJwtToken(AppUser appUser)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name,appUser.UserName),
                new Claim(JwtRegisteredClaimNames.Sub, appUser.UserName),
                new Claim(JwtRegisteredClaimNames.Email, appUser.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.NameIdentifier, appUser.Id)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _jwtSettings.Issuer,
                _jwtSettings.Audience,
                claims,
                DateTime.UtcNow,
                DateTime.UtcNow.AddDays(_jwtSettings.DaysToExpiration),
                credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
