﻿using AssetDispatchMgr.Api.Dto;
using AssetDispatchMgr.Api.Jwt;
using AssetDispatchMgr.Data.Model;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace AssetDispatchMgr.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly SignInManager<AppUser> _signInManager;
        private readonly UserManager<AppUser> _userManager;
        private JwtManager _authManager;

        public AuthController(JwtManager authManager,
            UserManager<AppUser> userManager,
            SignInManager<AppUser> signInManager,
            IMapper mapper)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _authManager = authManager;
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            try
            {
                var result = await _signInManager.PasswordSignInAsync(dto.Email, dto.Password, false, false);

                if (!result.Succeeded)
                    return Unauthorized("Please enter a correct username and password.");

                var userApp = _userManager.Users.SingleOrDefault(r => r.Email.Trim() == dto.Email.Trim());

                UserAutenticatedDto authUser = _authManager.BuildAthUserAsync(userApp);

                return Ok(authUser);
            }
            catch
            {
                return this.StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong please contact the support team");
            }
        }
    }
}
