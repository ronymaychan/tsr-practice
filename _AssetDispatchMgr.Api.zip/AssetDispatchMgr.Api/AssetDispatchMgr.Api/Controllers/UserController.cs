﻿using AssetDispatchMgr.Api.Dto;
using AssetDispatchMgr.Api.Extensions;
using AssetDispatchMgr.Api.Infrastructure.EmailService;
using AssetDispatchMgr.Data.Model;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace AssetDispatchMgr.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly IEmailSender _emailSender;
        private IMapper _mapper;

        public UserController(UserManager<AppUser> userManager,
            SignInManager<AppUser> signInManager,
            IEmailSender emailSender,
            IMapper mapper)
        {
            _userManager = userManager;
            _emailSender = emailSender;
            _mapper = mapper;
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> RegisterUserAsync([FromBody] UserRegisterDto model)
        {
            try
            {
                if (!ModelState.IsValid)
                    return new BadRequestObjectResult(ModelState.GenerateValidation());

                var user = new AppUser
                {
                    UserName = model.Email.Trim(),
                    Email = model.Email.Trim(),
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    IsConsultant = model.IsConsultant,
                    IsAdmin = model.IsAdmin,
                    IsManager = model.IsManager
                };

                var result = await _userManager.CreateAsync(user, model.Password.Trim());

                if (!result.Succeeded)
                    return new BadRequestObjectResult(result.GenerateIdentityValidation());

                var dto = _mapper.Map<UserDto>(user);

                SendRegisterEmail(user);

                return Ok(dto);
            }
            catch
            {
                return this.StatusCode((int)HttpStatusCode.InternalServerError, "Something went wrong please contact the support team");
            }
        }

        private void SendRegisterEmail(AppUser user) 
        {
            var sb = new StringBuilder();

            var template =  $"<br><div>"+
                "<h3>Welcome to Asset Dispatch System </h3>"+ 
                "<P>Thank you for joining in the system</P>" + 
                "<p><b>First name:</b> {{FirstName}}</p>" + 
                "<p><b>Last name:</b> {{LastName}}</p>" +
                "<p><b>Email:</b> {{Email}}</p>" +
                "</div><br>";

            var toList = new List<string>() { user.Email };
            var subject = "User registration";

            _emailSender.SendEmail(new Message(toList, subject, template));

        }
    }
}
