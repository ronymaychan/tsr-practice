
export class CreatePropertyDto {
  typeId: number | undefined;
  area:  string | undefined;
  address:  string | undefined;
  ownerName:  string | undefined;
  ownerContact:  string | undefined;
  estimateValue:  string | undefined;
  isSold:  boolean | undefined;
}

export class CreateUserDto {
  fullName: string | undefined;
  email:  string | undefined;
  password:  string | undefined;
  confirm:  string | undefined;
  roles: string[] = ['seller', 'buyer']
}

export class LoginDto {
  email:  string | undefined;
  password:  string | undefined;
}

export class UserDetailDto {
  userName:  string | undefined | null;
  userId:  string | undefined  | null;
  isAutenticated: boolean | undefined  | null;
}

