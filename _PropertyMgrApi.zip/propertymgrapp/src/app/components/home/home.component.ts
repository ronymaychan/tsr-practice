import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  userName : string;
  userId: string ;
  userRoles: string ;

  constructor(public _authService : AuthService,  private _router:Router) {
    var userDetailDto: any = this._authService.getUserDetail();
    this.userName = userDetailDto.userName;
    this.userId = userDetailDto.userId;
    this.userRoles = "Seller, Buyer";
  }

  ngOnInit(): void {
  }

  logout(){
    this._authService.logout();
    this._authService.isAutenticate = false;
  }

}
