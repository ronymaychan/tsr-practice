import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-property',
  templateUrl: './edit-property.component.html',
  styleUrls: ['./edit-property.component.css']
})
export class EditPropertyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
