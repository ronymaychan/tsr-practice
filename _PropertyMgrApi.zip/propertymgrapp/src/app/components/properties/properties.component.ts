import { Component, OnInit } from '@angular/core';
import { PropertiesService } from '../../services/properties.service';
import { NgForm } from '@angular/forms'
import { Router } from '@angular/router';

@Component({
  selector: 'app-properties',
  templateUrl: './properties.component.html',
  styleUrls: ['./properties.component.css']
})
export class PropertiesComponent implements OnInit {

  propertiesPaged: any[] = [];
  properties: any[] = [];
  types : any[] = [];

  filter: any ={
    type: "",
    area : "",
    estimateValue : ""
  }

  constructor(private propertiesService: PropertiesService) { }

  ngOnInit(): void {
    this.propertiesService.getAll(undefined, undefined, undefined).subscribe(data => {
      this.propertiesPaged = data;
      this.properties = data.items;
      console.log(data)
    });

    this.propertiesService.getTypes().subscribe(data => {
      this.types = data;
      console.log(data)
    });
  }

  search(){
    this.propertiesService.getAll(this.filter.type, this.filter.area, this.filter.value).subscribe(data => {
      this.propertiesPaged = data;
      this.properties = data.items;
      console.log(data)
    });
  }

  delete(id: any){
    this.propertiesService.deleteProperty(id).subscribe(data => {
      this.search();
    });
    
  }

  sellProperty(id: any){
    this.propertiesService.sellProperty(id).subscribe(data => {
      this.search();
    });
    
  }

}
