import { Component, OnInit } from '@angular/core';
import { PropertiesService } from '../../../services/properties.service';
import { NgForm } from '@angular/forms'
import { CreatePropertyDto } from 'src/app/shared/models/dto-models';
import { Router } from '@angular/router';

import swal from 'sweetalert2'; 

@Component({
  selector: 'app-create-property',
  templateUrl: './create-property.component.html',
  styleUrls: ['./create-property.component.css']
})
export class CreatePropertyComponent implements OnInit {

  types : any[] = [];
  property : CreatePropertyDto = new CreatePropertyDto();


  constructor(private propertiesService: PropertiesService, private _router:Router) { 

  }

  ngOnInit(): void {

    this.propertiesService.getTypes().subscribe(data => {
      this.types = data;
      console.log(data);
    });
  }

  createProperty(){
    if(this.property.typeId == null){
      swal.fire({
        icon: 'error',
        title: 'Oops...Bad Request',
        text:  'Please select a property type.' 
      })
    }else{

    this.property.isSold = false;
    this.property.typeId = Number(this.property.typeId);

    this.propertiesService
    .createProperty(this.property)
    .subscribe(response => {
      console.log(response);
      swal.fire(
        'Good job!',
        'Your property information was saved successfully!',
        'success'
      ).then(() => {
        this._router.navigate(['/properties']);
      });

    }, response => {

      let message = response.error.errors.join(', ');

      swal.fire({
        icon: 'error',
        title: 'Oops...' + response.statusText,
        text:  message 
      })
    });
  }
  }
}
