import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms'
import { CreateUserDto } from 'src/app/shared/models/dto-models';
import { Router } from '@angular/router';

import swal from 'sweetalert2';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user: CreateUserDto = new CreateUserDto();

  constructor(private _router: Router, private _authService: AuthService) { }

  ngOnInit(): void {
  }

  createUser() {


    this._authService
      .createUser(this.user)
      .subscribe(response => {
        console.log(response);
        swal.fire(
          'Good job!',
          'Your account information was saved successfully!',
          'success'
        ).then(() => {
          this._router.navigate(['/login']);
        });

      }, response => {

        let message = response.error.errors.join(', ');

        swal.fire({
          icon: 'error',
          title: 'Oops...' + response.statusText,
          text: message
        })
      });
  }

}
