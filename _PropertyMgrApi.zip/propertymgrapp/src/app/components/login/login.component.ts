import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms'
import { LoginDto } from 'src/app/shared/models/dto-models';
import { Router } from '@angular/router';

import swal from 'sweetalert2';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  logininfo: LoginDto = new LoginDto();

  constructor(private _router: Router, private _authService: AuthService) { }

  ngOnInit(): void {
  }

  login(){

      console.log(this.logininfo);

      this._authService.login(this.logininfo)
      .subscribe(response => {
        console.log(response);
        this._authService.handleAuthentication(response);
        this._authService.isAutenticate = true;
        this._router.navigate(['/home']);
      }, 
      response => {
        swal.fire({
          icon: 'error',
          title: 'Invalid login',
          text: "Please enter a correct username and password."
        });
      });
  }

}
