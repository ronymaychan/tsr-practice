import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { PropertiesComponent } from './components/properties/properties.component';
import { CreatePropertyComponent } from './components/properties/create-property/create-property.component';
import { EditPropertyComponent } from './components/properties/edit-property/edit-property.component';
import { environment } from '../environments/environment';
import { HomeComponent } from './components/home/home.component';

import { PropertiesService } from './services/properties.service'

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    RegisterComponent,
    PropertiesComponent,
    CreatePropertyComponent,
    EditPropertyComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    PropertiesService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
