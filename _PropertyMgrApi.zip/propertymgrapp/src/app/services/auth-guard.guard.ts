import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardGuard implements CanActivate {
  
  constructor(private auth:AuthService, private _router:Router) { }

  canActivate(next:ActivatedRouteSnapshot, state: RouterStateSnapshot){

    console.log(next);

    if(!this.auth.isAuthenticated()){
      this._router.navigate(['/home']);
      return false;
    }

    return true;

  }
  
}
