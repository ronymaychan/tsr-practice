import { Observable, throwError } from 'rxjs';
import { Injectable, Inject, Optional, InjectionToken } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse, HttpResponseBase, HttpErrorResponse } from '@angular/common/http';
import { CreatePropertyDto } from '../shared/models/dto-models';

import{ AppConfig } from '../app.config';


@Injectable({
  providedIn: 'root'
})
export class PropertiesService  {

  constructor(private http:HttpClient) {

   }

  getAll(type: string | null | undefined, area : string | null | undefined, value : string | null | undefined ) : Observable<any> {

    let headers =  new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem("token")
    });

    console.log(AppConfig.apiEndpoint);
    console.log(localStorage.getItem("token"));


    let url = AppConfig.apiEndpoint + "/api/property/getallpaged?";
    if (type !== undefined)
        url += "typeId=" + encodeURIComponent("" + type) + "&"; 
    if (area !== undefined)
        url += "area=" + encodeURIComponent("" + area) + "&"; 
    if (area !== undefined)
        url += "area=" + encodeURIComponent("" + value) + "&"; 

    url += "pageSize=" + encodeURIComponent("10000"); 

        console.log(url);

    return this.http.get(url, { headers });
  }

  getTypes() : Observable<any> {

    let headers =  new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem("token")
    });

    let endpoint = AppConfig.apiEndpoint + '/' + 'api/propertytype'; 

    return this.http.get(endpoint, { headers });
  }

  deleteProperty(id:any) : Observable<any> {

    let headers =  new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem("token")
    });

    let url = AppConfig.apiEndpoint + '/api/property/' + id; 

    return this.http.delete(url, { headers });
  }

  sellProperty(id:any) : Observable<any> {

    let headers =  new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem("token")
    });

    let url = AppConfig.apiEndpoint + "/api/property/sellproperty?";
    url += "id=" + encodeURIComponent("" + id) + "&"; 

    return this.http.get(url, { headers });
  }

  createProperty(property : CreatePropertyDto)
  {
    let headers =  new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem("token")
    });

    let url = AppConfig.apiEndpoint + "/api/property?";

    let body = JSON.stringify(property);
    console.log(body);

    return this.http.post(url, body ,{ headers });
  }
}
