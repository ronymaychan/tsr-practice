import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { Injectable, Inject, Optional, InjectionToken } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse, HttpResponseBase, HttpErrorResponse } from '@angular/common/http';
import { CreateUserDto, LoginDto, UserDetailDto } from '../shared/models/dto-models';

import{ AppConfig } from '../app.config';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  isAutenticate : boolean ;

  constructor(public router: Router, private http:HttpClient) {
    var userDetailDto: any = this.getUserDetail();
    this.isAutenticate = userDetailDto.isAutenticated;
  }

  createUser(user : CreateUserDto)
  {
    let headers =  new HttpHeaders({
      'Content-Type': 'application/json'
    });

    let url = AppConfig.apiEndpoint + "/api/auth/register";

    let body = JSON.stringify(user);
    console.log(body);

    return this.http.post(url, body ,{ headers });
  }

  public login(loginInfo : LoginDto): Observable<any> {
    let headers =  new HttpHeaders({
      'Content-Type': 'application/json'
    });

    let url = AppConfig.apiEndpoint + "/api/auth/login";

    let body = JSON.stringify(loginInfo);
    console.log(body);

    return this.http.post(url, body ,{ headers });
  }

  public handleAuthentication(authResult : any){
    const expiresAt = JSON.stringify(authResult.expireInSeconds + new Date().getTime());
    let userDetailDto = new UserDetailDto();
    userDetailDto.userName = authResult.userName;
    userDetailDto.userId = authResult.userId;
    userDetailDto.isAutenticated = true;
    this.setUserDetail(userDetailDto);
    localStorage.setItem('token', authResult.accessToken);
    localStorage.setItem('expires_at', expiresAt);
  }

  public logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('expires_at');
    this.removeUserDetail();
  }

  public isAuthenticated(): boolean {
    const expiresAt = JSON.parse(localStorage.getItem('expires_at') || "");
    return new Date().getTime() < expiresAt;
  }

  setUserDetail(userdetail :UserDetailDto){
    let json = JSON.stringify(userdetail);
    localStorage.setItem("userdetail", json);
  }

  getUserDetail():  UserDetailDto{

    let json = localStorage.getItem("userdetail")|| "{}";

    let jsonObj: any = JSON.parse(json);
    let userDetailDto: UserDetailDto = <UserDetailDto>jsonObj;

    return userDetailDto;
  }

  removeUserDetail(){
    localStorage.removeItem("userdetail");
  }

  getToken(){
    localStorage.getItem("token") || "";
  }

}
