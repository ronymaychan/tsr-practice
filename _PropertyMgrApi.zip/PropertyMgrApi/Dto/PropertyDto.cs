﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyMgrApi.Dto
{
    public class PropertyDto
    {
        public int Id { get; set; }
        public PropertyTypeDto Type { get; set; }
        public string Area { get; set; }
        public string Address { get; set; }
        public string OwnerName { get; set; }
        public string OwnerContact { get; set; }
        public string EstimateValue { get; set; }
    }
}
