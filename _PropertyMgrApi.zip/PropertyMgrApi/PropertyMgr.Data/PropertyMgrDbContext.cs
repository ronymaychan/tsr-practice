﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PropertyMgr.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyMgr.Data
{
    public class PropertyMgrDbContext : IdentityDbContext<UserApp, RoleApp, string>
    {
        public DbSet<Property> Properties { get; set; }
        public DbSet<PropertyType> PropertyTypes { get; set; }

        public PropertyMgrDbContext(DbContextOptions<PropertyMgrDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {

            builder.Entity<Property>(x => {
                x.HasKey(x => x.Id);
                x.Property(x => x.Id).ValueGeneratedOnAdd();
                x.Property(x => x.Area).HasMaxLength(50).IsRequired();
                x.Property(x => x.Address).HasMaxLength(100).IsRequired();
                x.Property(x => x.OwnerName).HasMaxLength(100).IsRequired();
                x.Property(x => x.OwnerContact).HasMaxLength(50).IsRequired();
                x.Property(x => x.EstimateValue).HasMaxLength(50).IsRequired();
                x.Property(x => x.IsSold).IsRequired();
                x.HasOne(x => x.Type).WithMany().HasForeignKey(x => x.TypeId);
                x.ToTable("Property");
            });

            builder.Entity<PropertyType>(x => {
                x.HasKey(x => x.Id);
                x.Property(x => x.Id).ValueGeneratedOnAdd();
                x.Property(x => x.Name).HasMaxLength(50).IsRequired();
                x.ToTable("PropertyType");
            });

            base.OnModelCreating(builder);
        }
    }
}
