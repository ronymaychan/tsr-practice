﻿using PropertyMgr.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PropertyMgr.Data.Base
{
    public interface IRepository<TEntity>
    {
        IQueryable<TEntity> GetAllQry();
        TEntity FindById(params object[] keyValues);
        void Insert(IEnumerable<TEntity> entities);
        void Insert(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);
        void Delete(IEnumerable<TEntity> entities);
    }
}
