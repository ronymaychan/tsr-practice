﻿using PropertyMgr.Data.Base;
using PropertyMgr.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyMgr.Data.Repositories
{
    public interface IPropertyTypeRepository : IRepository<PropertyType>
    {
        // place here the custom methods for this class
    }
}
