﻿using PropertyMgr.Data.Base;
using PropertyMgr.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyMgr.Data.Repositories.Impl
{
    public class PropertyTypeRepository : BaseRepository<PropertyType>, IPropertyTypeRepository
    {
        public PropertyTypeRepository(PropertyMgrDbContext context) : base(context)
        {
        }
    }
}
