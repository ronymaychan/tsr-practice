﻿using Microsoft.EntityFrameworkCore;
using PropertyMgr.Data.Base;
using PropertyMgr.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PropertyMgr.Data.Repositories.Impl
{
    public class PropertyRepository : BaseRepository<Property>, IPropertyRepository
    {
        public PropertyRepository(PropertyMgrDbContext context) : base(context)
        {
        }

        public override IQueryable<Property> GetAllQry()
        {
            return base.GetAllQry().Include(p => p.Type);
        }

        public override Property FindById(params object[] keyValues)
        {
            var property = _dbSet.Find(keyValues);

            if (property != null)
                property.Type = _context.PropertyTypes.FirstOrDefault(t => t.Id == property.Id);

            return property;
        }

        public PagedResultModel<Property> GetAllByPaging(int? typeId, string area, string value, int page = 0, int pageSize = 10)
        {
            if (pageSize <= 0) throw new ArgumentNullException("PageSize");

            IQueryable<Property> query = _dbSet.AsNoTracking().Include(x => x.Type);

            if (typeId != null)
                query = query.Where(x => x.TypeId == typeId);

            if (!string.IsNullOrEmpty(area))
                query = query.Where(x => x.Area.Contains(area));

            if (!string.IsNullOrEmpty(value))
                query = query.Where(x => x.EstimateValue.Contains(value));

            var response = new PagedResultModel<Property>();
            response.TotalRows = query.Count();
            response.TotalPages = (int)Math.Ceiling((double)response.TotalRows / pageSize);
            response.Items = query.Skip(pageSize * page).Take(pageSize).ToList();
            return response;
        }
    }
}
