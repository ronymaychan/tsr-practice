﻿using PropertyMgr.Data.Base;
using PropertyMgr.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyMgr.Data.Repositories.Impl
{
    public class UserRepository : BaseRepository<UserApp>, IUserRepository
    {
        public UserRepository(PropertyMgrDbContext context) : base(context)
        {
        }
    }
}
