﻿using PropertyMgr.Data.Base;
using PropertyMgr.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyMgr.Data.Repositories
{
    public interface IPropertyRepository : IRepository<Property>
    {
        // place here the custom methods for this class
        PagedResultModel<Property> GetAllByPaging(int? typeId, string area, string value, int page = 0, int pageSize = 10);
    }
}
