﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PropertyMgr.Data.Repositories;
using PropertyMgrApi.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace PropertyMgrApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyController : ControllerBase
    {

        private IMapper _mapper;
        private IPropertyRepository _propertyRepo;

        public PropertyController(IMapper mapper, IPropertyRepository propertyRepo)
        {
            _mapper = mapper;
            _propertyRepo = propertyRepo;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var properties = _propertyRepo.GetAllQry().ToList();
            var dtos = _mapper.Map<List<PropertyDto>>(properties);
            return Ok(dtos);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var type = _propertyRepo.FindById(id);

            if (type == null)
                return NotFound();

            var dto = _mapper.Map<PropertyDto>(type);
            return Ok(dto);
        }

        // POST api/<PropertyController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<PropertyController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<PropertyController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
