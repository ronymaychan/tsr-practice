﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PropertyMgr.Data.Repositories;
using PropertyMgr.Model;
using PropertyMgrApi.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace PropertyMgrApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyTypeController : ControllerBase
    {
        private IMapper _mapper;
        private IPropertyTypeRepository _propertyTypeRepo;

        public PropertyTypeController(IMapper mapper, IPropertyTypeRepository propertyTypeRepo)
        {
            _mapper = mapper;
            _propertyTypeRepo = propertyTypeRepo;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var types = _propertyTypeRepo.GetAllQry().ToList();
            var dtos = _mapper.Map<List<PropertyTypeDto>>(types);
            return Ok(dtos);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var type = _propertyTypeRepo.FindById(id);

            if (type == null)
                return NotFound(); 

            var dto = _mapper.Map<PropertyTypeDto>(type);
            return Ok(dto);
        }
    }
}
