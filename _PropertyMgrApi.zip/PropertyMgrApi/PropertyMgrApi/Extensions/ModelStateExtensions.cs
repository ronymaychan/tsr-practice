﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyMgrApi.Extensions
{
    public static class ModelStateExtensions
    {
        public static ValidationResponse GenerateValidation(this ModelStateDictionary dictionary)
        {
            var output = new List<string>();

            foreach (var dictionaryValue in dictionary.Values)
            {
                foreach (var error in dictionaryValue.Errors)
                {
                    output.Add(error.ErrorMessage);
                }
            }

            return new ValidationResponse
            {
                Errors = output
            };
        }

        public static ValidationResponse GenerateIdentityValidation(this Microsoft.AspNetCore.Identity.IdentityResult result)
        {
            var output = new List<string>();

            foreach (var error in result.Errors)
            {
                    output.Add(error.Description);
            }

            return new ValidationResponse
            {
                Errors = output
            };
        }
    }

    

    public class ValidationResponse
    {
        public IList<string> Errors { get; set; }
    }
}
