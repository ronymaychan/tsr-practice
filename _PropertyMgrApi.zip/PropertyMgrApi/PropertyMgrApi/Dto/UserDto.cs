﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyMgrApi.Dto
{
    public class RegisterUserDto
    {
        [EmailAddress]
        [Required]
        public string Email { get; set; }
        [Required]
        [MaxLength(20)]
        public string Password { get; set; }
        [Required]
        public List<string> Roles { get; set; }
    }

    public class UserDto
    {
        public string Id { get; set; }
        public string Email { get; set; }
        public List<string> Roles { get; set; }
    }

    public class LoginDto
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
    }

    public class AuthUserDto
    {
        public string UserName { get; set; }

        public string AccessToken { get; set; }

        public int ExpireInSeconds { get; set; }

        public string UserId { get; set; }

        public List<string> Claims { get; set; }

    }
}
