﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyMgrApi.Dto
{
    public class PropertyDto
    {
        public int Id { get; set; }
        public PropertyTypeDto Type { get; set; }
        public string Area { get; set; }
        public string Address { get; set; }
        public string OwnerName { get; set; }
        public string OwnerContact { get; set; }
        public string EstimateValue { get; set; }
        public bool IsSold { get; set; }
    }

    public class PropertyPagedResponseDto
    {
        public List<PropertyDto> Items { get; set; }
        public int TotalRows { get; set; }
        public int TotalPages { get; set; }

    }

    public class PropertyCreateDto
    {
        [Required]
        public int TypeId { get; set; }
        [Required]
        [MaxLength(50)]
        public string Area { get; set; }
        [Required]
        [MaxLength(100)]
        public string Address { get; set; }
        [Required]
        [MaxLength(100)]
        public string OwnerName { get; set; }
        [Required]
        [MaxLength(50)]
        public string OwnerContact { get; set; }
        [Required]
        [MaxLength(50)]
        public string EstimateValue { get; set; }
        [Required]
        public bool IsSold { get; set; }
    }

    public class PropertyUpdateDto
    {
        [Required]
        public int TypeId { get; set; }
        [Required]
        [MaxLength(50)]
        public string Area { get; set; }
        [Required]
        [MaxLength(100)]
        public string Address { get; set; }
        [Required]
        [MaxLength(100)]
        public string OwnerName { get; set; }
        [Required]
        [MaxLength(50)]
        public string OwnerContact { get; set; }
        [Required]
        [MaxLength(50)]
        public string EstimateValue { get; set; }
        public bool IsSold { get; set; }
    }

}
