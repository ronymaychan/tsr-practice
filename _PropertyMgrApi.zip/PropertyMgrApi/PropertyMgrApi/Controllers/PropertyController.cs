﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyMgr.Data.Repositories;
using PropertyMgr.Model;
using PropertyMgrApi.Dto;
using PropertyMgrApi.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace PropertyMgrApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyController : ControllerBase
    {

        private IMapper _mapper;
        private IPropertyRepository _propertyRepo;

        public PropertyController(IMapper mapper, IPropertyRepository propertyRepo)
        {
            _mapper = mapper;
            _propertyRepo = propertyRepo;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var properties = _propertyRepo.GetAllQry().ToList();
            var dtos = _mapper.Map<List<PropertyDto>>(properties);
            return Ok(dtos);
        }
        [HttpGet("getallpaged")]
        public IActionResult GetAllPaging(int? typeId = null, string area = null, string value = null, int page = 0, int pageSize = 10)
        {
            var pagedResponse = _propertyRepo.GetAllByPaging(typeId, area, value, page, pageSize);

            var responseDto = new PropertyPagedResponseDto()
            {
                Items = _mapper.Map<List<PropertyDto>>(pagedResponse.Items),
                TotalPages = pagedResponse.TotalPages,
                TotalRows = pagedResponse.TotalRows
            };

            return Ok(responseDto);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var type = _propertyRepo.FindById(id);

            if (type == null)
                return NotFound();

            var dto = _mapper.Map<PropertyDto>(type);
            return Ok(dto);
        }

        [HttpPost]
        public IActionResult Post([FromBody] PropertyCreateDto dto)
        {
            if (!ModelState.IsValid)
                return new BadRequestObjectResult(ModelState.GenerateValidation());

            try
            {
                var property = _mapper.Map<Property>(dto);
                _propertyRepo.Insert(property);
                return Ok(property.Id);
            }
            catch (Exception ex)
            {
                var response = this.StatusCode(500, ex.Message);
                return response;
            }
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] PropertyUpdateDto dto)
        {
            if (!ModelState.IsValid)
                return new BadRequestObjectResult(ModelState.GenerateValidation());

            var property = _propertyRepo.FindById(id);

            if (property == null)
                return NotFound();

            try
            {
                _mapper.Map(dto, property);
                _propertyRepo.Update(property);
                return Ok(property.Id);
            }
            catch (Exception ex)
            {
                var response = this.StatusCode(500, ex.Message);
                return response;
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var property = _propertyRepo.FindById(id);

                if (property == null)
                    return NotFound();

                _propertyRepo.Delete(property);

                return NoContent();
            }
            catch (Exception ex)
            {
                var response = StatusCode(500, ex.Message);
                return response;
            }
        }

        [HttpGet("sellproperty")]
        public IActionResult SellProperty(int id)
        {

            var property = _propertyRepo.FindById(id);

            if (property == null)
                return NotFound();

            try
            {
                property.IsSold = true;
                _propertyRepo.Update(property);
                return Ok(property.Id);
            }
            catch (Exception ex)
            {
                var response = this.StatusCode(500, ex.Message);
                return response;
            }
        }
    }
}
