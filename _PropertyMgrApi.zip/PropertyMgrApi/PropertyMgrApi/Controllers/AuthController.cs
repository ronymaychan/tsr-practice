﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PropertyMgr.Model;
using PropertyMgrApi.Dto;
using PropertyMgrApi.Extensions;
using PropertyMgrApi.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace PropertyMgrApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly SignInManager<UserApp> _signInManager;
        private readonly UserManager<UserApp> _userManager;
        private readonly RoleManager<RoleApp> _roleManager;
        private IMapper _mapper;
        private JwtManager _authManager;

        public AuthController(JwtManager authManager, UserManager<UserApp> userManager, 
            SignInManager<UserApp> signInManager, RoleManager<RoleApp> roleManager, 
            IMapper mapper)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _mapper = mapper;
            _authManager = authManager;
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            var result = await _signInManager.PasswordSignInAsync(dto.Email, dto.Password, false, false);

            if (!result.Succeeded)
                return Unauthorized("Please enter a correct username and password.");

            var userApp = _userManager.Users.SingleOrDefault(r => r.UserName.Trim() == dto.Email.Trim());

            AuthUserDto authUser = await _authManager.BuildAthuUserAsync(userApp);

            return Ok(authUser);
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> RegisterUserAsync([FromBody] RegisterUserDto model)
        {

            if (!ModelState.IsValid)
                return new BadRequestObjectResult(ModelState.GenerateValidation());

            var user = new UserApp { 
                UserName = model.Email.Trim(), 
                Email = model.Email.Trim()
            };

            var result = await _userManager.CreateAsync(user, model.Password.Trim());

            if (result.Succeeded)
            {
                foreach (var r in model.Roles)
                {
                    var roleExist = await _roleManager.RoleExistsAsync(r);
                    if (!roleExist)
                        await _roleManager.CreateAsync(new RoleApp() { Name = r, NormalizedName = r });
                    await _userManager.AddToRoleAsync(user, r);
                }

                var dto = _mapper.Map<UserDto>(user);
                dto.Roles = model.Roles;

                return Ok(dto);
            }
            else
            {
                return new BadRequestObjectResult(result.GenerateIdentityValidation());
            }

        }
    }
}
