﻿using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using PropertyMgr.Model;
using PropertyMgrApi.Dto;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace PropertyMgrApi.Infrastructure
{
    public class JwtManager
    {
        private JwtSettings _jwtSettings;

        private UserManager<UserApp> _userManager;

        private RoleManager<RoleApp> _roleManager;
        public JwtManager(JwtSettings jwtSettings, UserManager<UserApp> userManager, RoleManager<RoleApp> roleManager)
        {
            _jwtSettings = jwtSettings;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public async Task<AuthUserDto> BuildAthuUserAsync(UserApp userApp)
        {

            var urserRoles = await GeRolesAsync(userApp);

            AuthUserDto authUser = new AuthUserDto
            {
                UserName =  userApp.UserName,
                AccessToken = BuildJwtToken(userApp, urserRoles),
                UserId = userApp.Id,
                ExpireInSeconds = _jwtSettings.DaysToExpiration * 24 * 60 * 60, 
                Claims = urserRoles.Select(x => x.NormalizedName).ToList()

            };

            return authUser;
        }



        public string BuildJwtToken(UserApp userApp, List<RoleApp> roles)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name,userApp.UserName),
                new Claim(JwtRegisteredClaimNames.Sub, userApp.UserName),
                new Claim(JwtRegisteredClaimNames.Email, userApp.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.NameIdentifier, userApp.Id)
            };

            var rolesClaims = roles.Select(x => new Claim("role", x.NormalizedName));

            claims.AddRange(rolesClaims);

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_jwtSettings.Issuer, _jwtSettings.Audience, claims,
                DateTime.UtcNow, DateTime.UtcNow.AddDays(_jwtSettings.DaysToExpiration), credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public async Task<List<Claim>> GetClaimsAsync(UserApp userApp)
        {
            var claims = new List<Claim>();

            var userRoles = await _userManager.GetRolesAsync(userApp);
            foreach (var r in userRoles)
            {
                var role = await _roleManager.FindByNameAsync(r);
                claims.Add(new Claim("role", role.NormalizedName));
            }

            return claims;
        }

        public async Task<List<RoleApp>> GeRolesAsync(UserApp userApp)
        {
            var roles = new List<RoleApp>();

            var userRoles = await _userManager.GetRolesAsync(userApp);
            foreach (var r in userRoles)
                roles.Add(await _roleManager.FindByNameAsync(r));

            return roles;
        }
    }
}
