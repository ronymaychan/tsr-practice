﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyMgr.Model
{
    public class Property
    {
        public int Id { get; set; }
        public int TypeId { get; set; }
        public PropertyType Type { get; set; }
        public string Area { get; set; }
        public string Address { get; set; }
        public string OwnerName { get; set; }
        public string OwnerContact { get; set; }
        public string EstimateValue { get; set; }
        public bool IsSold { get; set; }
    }
}
