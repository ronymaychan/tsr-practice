﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyMgr.Model
{
    public class PagedResultModel<T>
    {
        public int TotalRows { get; set; }
        public int TotalPages { get; set; }

        public List<T> Items { get; set; }
    }
}
