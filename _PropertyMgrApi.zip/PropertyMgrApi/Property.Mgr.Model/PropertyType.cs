﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PropertyMgr.Model
{
    public class PropertyType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
